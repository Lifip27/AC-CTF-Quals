# server

A Minecraft server implement based on [go-mc](https://github.com/Tnze/go-mc)